# Συστηματα Ληψης Αποφασεων Εκφωνηση 1
## Μαυροπουλος Ανδρεας 217129
Για τα imports χρησιμοποιησα numpy, pandas, sklearn,matplotlib, seaborn, plotly, scipy, catboost, xgboost

Για να τρέξει ολο το notebook πέρα απο ολα τα imports θα χρειαστεί στο δεύτερο cell να αλλάξετε το path για τα αρχεια.Ενναλακτικά μπορέιτε με το παρακάτω link να πάρετε ολο το notebook. Πιθανά να χρειαστεί στο δευτερο cell να γίνει παλι αλλαγη στο path.



Link for collab : https://colab.research.google.com/drive/1F5cWXGgDRjoTyHfIffbmu_mHGzP7WlJX?usp=sharing 
